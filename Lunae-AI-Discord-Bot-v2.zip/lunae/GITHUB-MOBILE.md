# Uploading Lunae to GitHub from Mobile

GitHub mobile web may flatten uploaded folders. Do not upload this ZIP as the repository contents.

The easiest approach is to upload files using these exact paths:

- `src/index.js`
- `src/ai.js`
- `src/config.js`
- `src/knowledge.js`
- `src/deploy-commands.js`
- `src/commands/lunae.js`
- `knowledge/Lunarion.lua`
- `knowledge/api.md`
- `knowledge/README.md`
- `.github/workflows/ci.yml`
- `.env.example`
- `.gitignore`
- `package.json`
- `README.md`

When creating/editing a file on GitHub, putting `/` in the filename creates the required folders automatically.

Keep `.env`, bot tokens, and AI API keys out of GitHub.
