# Lunae 🌙

Lunae is a Discord AI assistant focused on the Lunarion Roblox UI library.

## Features

- `/lunae ask` — ask questions about Lunarion
- `/lunae code` — request Lunarion code
- `/lunae explain` — explain an API/component
- `/lunae debug` — analyze Lunarion code
- `/lunae api` — search the indexed Lunarion API notes
- `/lunae themes` — list known Lunarion themes
- `/lunae help` — show commands

Lunae is designed to ground answers in the Lunarion source stored in GitHub. It should not invent APIs when the source does not support them.

## Setup

1. Install Node.js 20+.
2. Copy `.env.example` to `.env`.
3. Fill in the Discord and AI credentials.
4. Put your Lunarion source at `knowledge/Lunarion.lua` or configure `GITHUB_RAW_URL`.
5. Run:

```bash
npm install
npm run register
npm start
```

For development, set `DISCORD_GUILD_ID` so slash commands register immediately in one server.

## GitHub Actions

A workflow is included for syntax checking on pushes and pull requests.

## Security

Never commit `.env`, Discord tokens, or AI API keys.
