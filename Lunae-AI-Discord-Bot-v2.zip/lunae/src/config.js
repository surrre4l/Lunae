import 'dotenv/config';

function required(name) {
  const value = process.env[name];
  if (!value) throw new Error(`Missing required environment variable: ${name}`);
  return value;
}

export const config = {
  discordToken: required('DISCORD_TOKEN'),
  clientId: required('DISCORD_CLIENT_ID'),
  guildId: process.env.DISCORD_GUILD_ID || '',
  aiApiKey: required('AI_API_KEY'),
  aiApiUrl: process.env.AI_API_URL || 'https://api.openai.com/v1/chat/completions',
  aiModel: required('AI_MODEL'),
  githubRepo: process.env.GITHUB_REPO || 'surrre4l/Lunarion',
  githubBranch: process.env.GITHUB_BRANCH || 'main',
  githubSourcePath: process.env.GITHUB_SOURCE_PATH || 'knowledge/Lunarion.lua',
  githubRawUrl: process.env.GITHUB_RAW_URL || ''
};
