import { REST, Routes } from 'discord.js';
import { config } from './config.js';
import { data } from './commands/lunae.js';

const rest = new REST({ version: '10' }).setToken(config.discordToken);
const route = config.guildId
  ? Routes.applicationGuildCommands(config.clientId, config.guildId)
  : Routes.applicationCommands(config.clientId);

await rest.put(route, { body: [data.toJSON()] });
console.log(config.guildId ? 'Lunae commands registered to the test guild.' : 'Lunae global commands registered.');
