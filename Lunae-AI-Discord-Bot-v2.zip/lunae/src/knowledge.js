import { config } from './config.js';

let cached = null;
let cachedAt = 0;
const CACHE_MS = 5 * 60 * 1000;

function rawGithubUrl() {
  return config.githubRawUrl ||
    `https://raw.githubusercontent.com/${config.githubRepo}/${config.githubBranch}/${config.githubSourcePath}`;
}

export async function getLunarionSource() {
  if (cached && Date.now() - cachedAt < CACHE_MS) return cached;

  const response = await fetch(rawGithubUrl(), {
    headers: { 'User-Agent': 'Lunae-Discord-Bot' }
  });

  if (!response.ok) {
    throw new Error(`GitHub source request failed: ${response.status}`);
  }

  cached = await response.text();
  cachedAt = Date.now();
  return cached;
}

export function trimKnowledge(source, maxChars = 70000) {
  if (source.length <= maxChars) return source;
  return source.slice(0, maxChars) + '\n\n-- Source truncated for context limits --';
}

export function invalidateKnowledgeCache() {
  cached = null;
  cachedAt = 0;
}
