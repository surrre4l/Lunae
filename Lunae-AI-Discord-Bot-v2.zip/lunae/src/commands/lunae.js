import { SlashCommandBuilder, EmbedBuilder } from 'discord.js';
import { answerLunae } from '../ai.js';
import { getLunarionSource } from '../knowledge.js';

export const data = new SlashCommandBuilder()
  .setName('lunae')
  .setDescription('Ask Lunae about the Lunarion UI library.')
  .addSubcommand(sub => sub
    .setName('ask')
    .setDescription('Ask a Lunarion question.')
    .addStringOption(o => o.setName('question').setDescription('Your question').setRequired(true)))
  .addSubcommand(sub => sub
    .setName('code')
    .setDescription('Generate Lunarion code.')
    .addStringOption(o => o.setName('request').setDescription('What should the code do?').setRequired(true)))
  .addSubcommand(sub => sub
    .setName('explain')
    .setDescription('Explain a Lunarion API or component.')
    .addStringOption(o => o.setName('api').setDescription('API or component name').setRequired(true)))
  .addSubcommand(sub => sub
    .setName('debug')
    .setDescription('Debug Lunarion code.')
    .addStringOption(o => o.setName('code').setDescription('Lua code to debug').setRequired(true)))
  .addSubcommand(sub => sub
    .setName('api')
    .setDescription('Search the Lunarion source for an API name.')
    .addStringOption(o => o.setName('name').setDescription('API name').setRequired(true)))
  .addSubcommand(sub => sub.setName('themes').setDescription('Show known Lunarion themes.'))
  .addSubcommand(sub => sub.setName('help').setDescription('Show Lunae commands.'));

function chunks(text, max = 1900) {
  const out = [];
  for (let i = 0; i < text.length; i += max) out.push(text.slice(i, i + max));
  return out;
}

export async function execute(interaction) {
  const sub = interaction.options.getSubcommand();

  if (sub === 'help') {
    return interaction.reply({
      embeds: [new EmbedBuilder()
        .setTitle('🌙 Lunae')
        .setDescription('AI assistant specialized in the Lunarion UI library.')
        .addFields(
          { name: '/lunae ask', value: 'Ask a Lunarion question.' },
          { name: '/lunae code', value: 'Generate Lunarion Lua.' },
          { name: '/lunae explain', value: 'Explain an API/component.' },
          { name: '/lunae debug', value: 'Debug Lunarion Lua.' },
          { name: '/lunae api', value: 'Search the indexed source.' },
          { name: '/lunae themes', value: 'Show known themes.' }
        )]
    });
  }

  if (sub === 'themes') {
    return interaction.reply('Known Lunarion v3.0.0 themes from the indexed source: Lunarion, Default, Amethyst, Ocean, Rose, Emerald, Light, Sakura.');
  }

  if (sub === 'api') {
    await interaction.deferReply();
    const name = interaction.options.getString('name', true);
    const source = await getLunarionSource();
    const lower = source.toLowerCase();
    const index = lower.indexOf(name.toLowerCase());
    if (index === -1) return interaction.editReply(`I couldn't verify **${name}** in the indexed Lunarion source.`);
    const start = Math.max(0, index - 500);
    const excerpt = source.slice(start, Math.min(source.length, index + name.length + 1200));
    return interaction.editReply(`Found **${name}** in the indexed source:\n\`\`\`lua\n${excerpt.slice(0, 1800)}\n\`\`\``);
  }

  await interaction.deferReply();

  try {
    const value = interaction.options.getString(sub === 'ask' ? 'question' : sub === 'code' ? 'request' : sub === 'explain' ? 'api' : 'code', true);
    const answer = await answerLunae(value, sub);
    const parts = chunks(answer);
    await interaction.editReply(parts.shift() || 'No response.');
    for (const part of parts) await interaction.followUp(part);
  } catch (error) {
    console.error(error);
    await interaction.editReply('Lunae hit an error while processing that request. Check the bot logs for details.');
  }
}
