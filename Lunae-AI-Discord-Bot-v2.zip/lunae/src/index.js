import { Client, GatewayIntentBits, Events } from 'discord.js';
import { config } from './config.js';
import { data, execute } from './commands/lunae.js';

const client = new Client({ intents: [GatewayIntentBits.Guilds] });

client.once(Events.ClientReady, ready => {
  console.log(`🌙 Lunae online as ${ready.user.tag}`);
});

client.on(Events.InteractionCreate, async interaction => {
  if (!interaction.isChatInputCommand()) return;
  if (interaction.commandName !== data.name) return;

  try {
    await execute(interaction);
  } catch (error) {
    console.error(error);
    const message = 'Something went wrong while running that command.';
    if (interaction.deferred || interaction.replied) await interaction.editReply(message).catch(() => {});
    else await interaction.reply({ content: message, ephemeral: true }).catch(() => {});
  }
});

process.on('unhandledRejection', console.error);
process.on('uncaughtException', console.error);

client.login(config.discordToken);
