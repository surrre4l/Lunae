# Lunarion Knowledge

Place the authoritative Lunarion source here as `Lunarion.lua`, or point `GITHUB_RAW_URL` at the raw GitHub file containing the source.

Lunae treats this source as its primary API reference and should say when an API cannot be verified from it.
