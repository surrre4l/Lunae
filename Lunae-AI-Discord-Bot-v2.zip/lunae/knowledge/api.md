# Lunarion API Notes

This file is intentionally minimal. Lunae should use the authoritative `Lunarion.lua` source for exact API details.

Known source-backed concepts for the current Lunarion v3 line include:

- `MakeKeySystem(Config)`
- `MakeWindow(Config)`
- `MakeTabSection(...)`
- `MakeTab(...)`
- `Window:SetTabStyle("Top")`
- Window `Homeboard` configuration
- Theme support including Lunarion, Default, Amethyst, Ocean, Rose, Emerald, Light, and Sakura

Do not add API claims here unless they are verified against the source.
